package org.ojan.catalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookCatalogV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
